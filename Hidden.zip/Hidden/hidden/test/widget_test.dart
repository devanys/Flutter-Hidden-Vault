import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hidden/main.dart';

void main() {
  testWidgets('Login screen loads with PIN prompt or setup', (WidgetTester tester) async {
    // Simulasikan SharedPreferences kosong
    SharedPreferences.setMockInitialValues({});

    // Jalankan aplikasi
    await tester.pumpWidget(const Myapp());

    // Tunggu sampai FutureBuilder selesai
    await tester.pumpAndSettle();

    // Cek teks yang relevan (Set PIN atau Masukkan PIN tergantung kondisi)
    expect(find.textContaining('PIN'), findsWidgets);

    // Cek tombol (bisa "Simpan PIN" atau "Masuk" tergantung kondisi awal)
    expect(find.widgetWithText(ElevatedButton, 'Simpan PIN').hitTestable(), findsOneWidget);
  });
}

import 'package:flutter/material.dart';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'preview_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<File> hiddenFiles = [];

  @override
  void initState() {
    super.initState();
    _loadHiddenFiles();
  }

  Future<Directory> getHiddenVaultDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final hiddenDir = Directory('${dir.path}/.hiddenvault');

    if (!await hiddenDir.exists()) {
      await hiddenDir.create(recursive: true);
      final nomedia = File('${hiddenDir.path}/.nomedia');
      await nomedia.create(); // Supaya folder tidak terindeks galeri
    }

    return hiddenDir;
  }

  Future<void> _loadHiddenFiles() async {
    try {
      final dir = await getHiddenVaultDir();
      final files = dir
          .listSync()
          .whereType<File>()
          .where((f) => path.basename(f.path) != '.nomedia')
          .toList();

      setState(() {
        hiddenFiles = files;
      });
    } catch (e) {
      debugPrint('Gagal memuat file: $e');
    }
  }

  Future<void> _importFiles() async {
    final status = await Permission.storage.request();
    if (!status.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Izin akses penyimpanan ditolak')),
      );
      return;
    }

    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg', 'png', 'mp4', 'mov'],
    );

    if (result != null && result.files.isNotEmpty) {
      final dir = await getHiddenVaultDir();

      for (var file in result.files) {
        try {
          if (file.path == null) continue;

          final sourceFile = File(file.path!);
          final fileName = path.basename(file.path!);
          final targetPath = path.join(dir.path, fileName);

          await sourceFile.copy(targetPath);

          // Hapus file asli agar tidak muncul di galeri
          try {
            await sourceFile.delete();
          } catch (e) {
            debugPrint('Gagal menghapus file asli: $e');
          }
        } catch (e) {
          debugPrint('Gagal mengimpor file: $e');
        }
      }

      _loadHiddenFiles(); // refresh tampilan
    }
  }

  Future<void> _confirmDeleteFile(File file) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus File'),
        content: const Text('Apakah kamu yakin ingin menghapus file ini dari vault?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );

    if (shouldDelete == true) {
      try {
        await file.delete();
        _loadHiddenFiles();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('File berhasil dihapus')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal menghapus file: $e')),
        );
      }
    }
  }

  Widget _buildFileTile(File file) {
    final ext = path.extension(file.path).toLowerCase();
    if (['.jpg', '.jpeg', '.png'].contains(ext)) {
      return Image.file(file, fit: BoxFit.cover);
    } else if (['.mp4', '.mov'].contains(ext)) {
      return const Icon(Icons.videocam, size: 50, color: Colors.grey);
    } else {
      return const Icon(Icons.insert_drive_file, size: 50, color: Colors.grey);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Vault'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: _importFiles,
            tooltip: 'Import File',
          ),
        ],
      ),
      body: hiddenFiles.isEmpty
          ? const Center(child: Text('Tidak ada file.'))
          : GridView.builder(
              itemCount: hiddenFiles.length,
              padding: const EdgeInsets.all(8),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
              ),
              itemBuilder: (context, index) {
                final file = hiddenFiles[index];
                return Card(
                  clipBehavior: Clip.hardEdge,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PreviewScreen(file: file),
                        ),
                      );
                    },
                    onLongPress: () => _confirmDeleteFile(file),
                    child: _buildFileTile(file),
                  ),
                );
              },
            ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/home_screen.dart';
import 'screens/pin_lock_screen.dart';
import 'screens/pin_setup_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  Future<Widget> _decideStartScreen() async {
    final prefs = await SharedPreferences.getInstance();
    final hasPin = prefs.containsKey('vault_pin');
    return hasPin ? const PinLockScreen() : const PinSetupScreen();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hidden Vault',
      theme: ThemeData.dark(),
      home: FutureBuilder(
        future: _decideStartScreen(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return snapshot.data as Widget;
          } else {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
        },
      ),
    );
  }
}

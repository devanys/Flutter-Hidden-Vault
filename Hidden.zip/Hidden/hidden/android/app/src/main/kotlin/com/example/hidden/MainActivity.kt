package com.example.hidden

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
